#!/usr/bin/env python3
"""Print torch device / MPS availability (Mac-friendly)."""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import torch
from src.device import get_device


def main() -> None:
    print("torch", torch.__version__)
    print("mps_available", torch.backends.mps.is_available())
    print("mps_built", torch.backends.mps.is_built())
    print("cuda_available", torch.cuda.is_available())
    device = get_device()
    print("device", device)
    x = torch.ones(1, device=device)
    print("tensor", x)


if __name__ == "__main__":
    main()

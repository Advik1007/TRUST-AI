"""Trust 1.0 email agent — Gemini only for Google-style send_email tool calling."""

from __future__ import annotations

import json
import os
import sys
from typing import Any

from dotenv import load_dotenv

from src.brand import AI_NAME, GOOGLE_TOOL_RULE, PRODUCT_NAME
from src.email_tool import send_email

load_dotenv()

SEND_EMAIL_DECL: dict[str, Any] = {
    "name": "send_email",
    "description": "Send an email via SMTP (Gmail/Google mail path).",
    "parameters": {
        "type": "object",
        "properties": {
            "recipient": {"type": "string", "description": "Email address"},
            "subject": {"type": "string"},
            "body": {"type": "string"},
        },
        "required": ["recipient", "subject", "body"],
    },
}


def _api_key() -> str | None:
    return (os.getenv("GEMINI_API_KEY") or os.getenv("AI_API_KEY") or "").strip() or None


def run_assistant(user_text: str) -> str:
    key = _api_key()
    if not key:
        return (
            f"{AI_NAME}: add GEMINI_API_KEY to .env to use Google email tools. "
            "Local predict still works without it (python -m src.inference)."
        )

    from google import genai
    from google.genai import types

    client = genai.Client(api_key=key)
    model = (os.getenv("AI_MODEL") or "gemini-2.0-flash").strip()

    system = (
        f"You are {AI_NAME}, the assistant inside {PRODUCT_NAME}. "
        f"{GOOGLE_TOOL_RULE} "
        "When the user wants to email someone, call send_email. "
        "Otherwise reply briefly as Trust 1.0. Never say you are Gemini."
    )

    tools = [types.Tool(function_declarations=[SEND_EMAIL_DECL])]
    config = types.GenerateContentConfig(
        system_instruction=system,
        tools=tools,
        temperature=0.4,
    )

    chat = client.chats.create(model=model, config=config)
    response = chat.send_message(user_text)

    # Explicit tool loop — execute send_email when Gemini requests it.
    for _ in range(4):
        parts = []
        if response.candidates and response.candidates[0].content:
            parts = response.candidates[0].content.parts or []

        fn_calls = [p.function_call for p in parts if getattr(p, "function_call", None)]
        if not fn_calls:
            break

        tool_responses = []
        for call in fn_calls:
            name = call.name
            args = dict(call.args or {})
            if name == "send_email":
                result = send_email(
                    recipient=str(args.get("recipient") or args.get("to") or ""),
                    subject=str(args.get("subject") or ""),
                    body=str(args.get("body") or ""),
                )
            else:
                result = {"ok": False, "error": f"unknown tool {name}"}
            tool_responses.append(
                types.Part.from_function_response(name=name, response=result)
            )

        response = chat.send_message(tool_responses)

    text = (response.text or "").strip()
    if text:
        return text
    return f"{AI_NAME}: done."


def main() -> None:
    prompt = " ".join(sys.argv[1:]).strip() or "Email me a short hello from Trust 1.0"
    print(run_assistant(prompt))


if __name__ == "__main__":
    main()

"""Trust 1.0 on-device stub model."""

from __future__ import annotations

import torch
from torch import nn


class TrustAIModel(nn.Module):
    """Small MLP stub — replace with a real Trust 1.0 checkpoint later."""

    def __init__(
        self,
        input_dim: int = 16,
        hidden_dim: int = 32,
        num_classes: int = 3,
    ) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, num_classes),
        )
        self.input_dim = input_dim
        self.num_classes = num_classes

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)

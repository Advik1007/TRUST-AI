"""Thin Gemini transport — used only as a Google-backed engine for Trust AI."""

from __future__ import annotations

import os
from typing import Any

from dotenv import load_dotenv

load_dotenv()


def api_key() -> str | None:
    return (os.getenv("GEMINI_API_KEY") or os.getenv("AI_API_KEY") or "").strip() or None


def model_name() -> str:
    return (os.getenv("AI_MODEL") or "gemini-2.0-flash").strip()


def generate_text(
    *,
    system: str,
    user: str,
    temperature: float = 0.5,
    json_mode: bool = False,
) -> str | None:
    key = api_key()
    if not key:
        return None

    from google import genai
    from google.genai import types

    client = genai.Client(api_key=key)
    config_kwargs: dict[str, Any] = {
        "system_instruction": system,
        "temperature": temperature,
    }
    if json_mode:
        config_kwargs["response_mime_type"] = "application/json"

    response = client.models.generate_content(
        model=model_name(),
        contents=user,
        config=types.GenerateContentConfig(**config_kwargs),
    )
    return (response.text or "").strip() or None

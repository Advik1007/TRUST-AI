"""Trust AI Student Mode — guided learning, not answer dumps."""

from __future__ import annotations

import sys

from src.brand import AI_NAME, PRODUCT_NAME
from src.gemini_client import api_key, generate_text
from src.prompts import STUDENT_SYSTEM


def student_reply(question: str) -> str:
    q = question.strip()
    if not q:
        return f"{PRODUCT_NAME}: What topic or problem should we work through?"

    if not api_key():
        return _offline_scaffold(q)

    text = generate_text(system=STUDENT_SYSTEM, user=q, temperature=0.55)
    if not text:
        return _offline_scaffold(q)
    return text


def _offline_scaffold(question: str) -> str:
    return f"""## {PRODUCT_NAME} Student Assistant ({AI_NAME})

Cloud study mode needs `GEMINI_API_KEY` in `.env`. Meanwhile, here's how we'll tackle it:

### Your question
{question}

### Approach
- Restate what the problem is asking in your own words.
- List knowns / unknowns.
- Name the concept or formula that applies.
- Work one step at a time — check each step before moving on.

### Practice
Write one sentence explaining *why* the first step matters for this problem.

Add `GEMINI_API_KEY` for a full guided walkthrough.
"""


def main() -> None:
    q = " ".join(sys.argv[1:]).strip() or "Explain photosynthesis simply for a class 8 student"
    print(student_reply(q))


if __name__ == "__main__":
    main()

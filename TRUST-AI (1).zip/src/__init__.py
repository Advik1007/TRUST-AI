"""Trust AI — Trust 1.0 local assistant ecosystem."""

__version__ = "1.0.0"
PRODUCT_NAME = "Trust AI"
AI_NAME = "Trust 1.0"
AGENTS = ("chat", "student", "action_parser", "predict", "email")

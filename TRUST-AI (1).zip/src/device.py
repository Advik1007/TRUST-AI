"""Pick the best local torch device (MPS on Apple Silicon, else CPU)."""

from __future__ import annotations

import os

import torch


def get_device() -> torch.device:
    forced = (os.getenv("TORCH_DEVICE") or "").strip().lower()
    if forced in {"mps", "cpu", "cuda"}:
        if forced == "mps" and not (
            torch.backends.mps.is_available() and torch.backends.mps.is_built()
        ):
            return torch.device("cpu")
        if forced == "cuda" and not torch.cuda.is_available():
            return torch.device("cpu")
        return torch.device(forced)

    if torch.backends.mps.is_available() and torch.backends.mps.is_built():
        return torch.device("mps")
    if torch.cuda.is_available():
        return torch.device("cuda")
    return torch.device("cpu")

"""Trust AI main chat — routes to student mode or action parsing when needed."""

from __future__ import annotations

import json
import sys
from typing import Any

from src.action_parser import parse_actions
from src.brand import AI_NAME, PRODUCT_NAME
from src.gemini_client import api_key, generate_text
from src.prompts import CORE_SYSTEM
from src.student_assistant import student_reply


def looks_academic(text: str) -> bool:
    lower = text.lower()
    cues = (
        "homework",
        "assignment",
        "explain",
        "solve",
        "study",
        "exam",
        "quiz",
        "equation",
        "derive",
        "prove",
        "what is",
        "how does",
        "calculate",
        "chapter",
        "lesson",
    )
    return any(c in lower for c in cues)


def looks_actionable(text: str) -> bool:
    lower = text.lower()
    cues = (
        "email",
        "gmail",
        "calendar",
        "schedule",
        "meeting",
        "task",
        "todo",
        "remind",
        "reminder",
        "due",
    )
    return any(c in lower for c in cues)


def chat(user_text: str, *, mode: str | None = None) -> dict[str, Any]:
    text = user_text.strip()
    if not text:
        return {
            "assistant": PRODUCT_NAME,
            "engine": AI_NAME,
            "mode": "idle",
            "reply": f"Hi — I'm {PRODUCT_NAME}. Ask a study question, or tell me to schedule / email / add a task.",
        }

    chosen = (mode or "").strip().lower()
    if chosen in {"student", "study"} or (not chosen and looks_academic(text) and not looks_actionable(text)):
        return {
            "assistant": PRODUCT_NAME,
            "engine": AI_NAME,
            "mode": "student",
            "reply": student_reply(text),
        }

    if chosen in {"action", "parse"} or (not chosen and looks_actionable(text)):
        action = parse_actions(text)
        reply = (
            f"I mapped that to a {PRODUCT_NAME} action."
            if action.get("status") == "ready"
            else action.get("message")
            or "I need a bit more detail before I can run that."
        )
        return {
            "assistant": PRODUCT_NAME,
            "engine": AI_NAME,
            "mode": "action",
            "reply": reply,
            "action": action,
        }

    if not api_key():
        return {
            "assistant": PRODUCT_NAME,
            "engine": AI_NAME,
            "mode": "offline",
            "reply": (
                f"I'm {PRODUCT_NAME} ({AI_NAME}). Add GEMINI_API_KEY to `.env` for full chat. "
                "I can still parse actions offline and run local `/predict`."
            ),
        }

    reply = generate_text(system=CORE_SYSTEM, user=text, temperature=0.6)
    return {
        "assistant": PRODUCT_NAME,
        "engine": AI_NAME,
        "mode": "chat",
        "reply": reply or f"{PRODUCT_NAME}: I hit a snag generating a reply. Try again?",
    }


def main() -> None:
    mode = None
    args = sys.argv[1:]
    if args and args[0] in {"--student", "--action", "--chat"}:
        mode = args[0].removeprefix("--")
        if mode == "chat":
            mode = "chat"
        elif mode == "student":
            mode = "student"
        elif mode == "action":
            mode = "action"
        args = args[1:]
    text = " ".join(args).strip() or "Who are you?"
    print(json.dumps(chat(text, mode=mode), indent=2))


if __name__ == "__main__":
    main()

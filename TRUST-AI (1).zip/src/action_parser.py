"""Trust AI Action Parser — Calendar / Tasks / Gmail intent → JSON."""

from __future__ import annotations

import json
import re
import sys
from typing import Any

from src.gemini_client import api_key, generate_text
from src.prompts import ACTION_PARSER_SYSTEM

SUPPORTED = {
    "create_calendar_event",
    "create_task",
    "send_email",
}


def parse_actions(user_request: str) -> dict[str, Any]:
    text = user_request.strip()
    if not text:
        return {
            "action": None,
            "status": "needs_clarification",
            "missing": ["request"],
            "message": "No user request provided.",
        }

    if api_key():
        raw = generate_text(
            system=ACTION_PARSER_SYSTEM,
            user=text,
            temperature=0.1,
            json_mode=True,
        )
        if raw:
            parsed = _safe_json(raw)
            if parsed:
                return _normalize(parsed)

    return _heuristic_parse(text)


def _safe_json(raw: str) -> dict[str, Any] | None:
    try:
        data = json.loads(raw)
        return data if isinstance(data, dict) else None
    except json.JSONDecodeError:
        match = re.search(r"\{[\s\S]*\}", raw)
        if not match:
            return None
        try:
            data = json.loads(match.group(0))
            return data if isinstance(data, dict) else None
        except json.JSONDecodeError:
            return None


def _normalize(data: dict[str, Any]) -> dict[str, Any]:
    action = data.get("action")
    status = data.get("status") or ("ready" if action in SUPPORTED else "none")
    if action and action not in SUPPORTED and status == "ready":
        return {
            "action": None,
            "status": "none",
            "message": f"Unsupported action: {action}",
        }
    out: dict[str, Any] = {
        "action": action if action in SUPPORTED else None,
        "status": status,
    }
    if "params" in data:
        out["params"] = data["params"]
    if "missing" in data:
        out["missing"] = data["missing"]
    if "message" in data:
        out["message"] = data["message"]
    return out


def _heuristic_parse(text: str) -> dict[str, Any]:
    lower = text.lower()

    if any(w in lower for w in ("email", "mail", "gmail", "send to")):
        missing = []
        recipient = _extract_email(text)
        if not recipient:
            missing.append("recipient")
        subject = None
        body = text
        if "subject" in lower:
            subject = text
        if missing:
            return {
                "action": "send_email",
                "status": "needs_clarification",
                "missing": missing,
                "params": {
                    "recipient": recipient,
                    "subject": subject,
                    "body": body,
                },
                "message": "Need recipient email (and ideally subject/body).",
            }
        return {
            "action": "send_email",
            "status": "ready",
            "params": {
                "recipient": recipient,
                "subject": subject or "Message from Trust AI",
                "body": body,
            },
        }

    if any(w in lower for w in ("calendar", "schedule", "meeting", "appointment")):
        return {
            "action": "create_calendar_event",
            "status": "needs_clarification",
            "missing": ["title", "start_time", "end_time"],
            "params": {"title": None, "start_time": None, "end_time": None, "description": text},
            "message": "Need event title and start/end times.",
        }

    if any(w in lower for w in ("task", "todo", "remind", "reminder", "due")):
        return {
            "action": "create_task",
            "status": "needs_clarification",
            "missing": ["title"],
            "params": {"title": None, "due_date": None, "notes": text},
            "message": "Need a clear task title (due date optional).",
        }

    return {
        "action": None,
        "status": "none",
        "message": "No supported action found.",
    }


def _extract_email(text: str) -> str | None:
    match = re.search(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}", text)
    return match.group(0) if match else None


def main() -> None:
    req = " ".join(sys.argv[1:]).strip() or "Email alex@example.com about Friday study group"
    print(json.dumps(parse_actions(req), indent=2))


if __name__ == "__main__":
    main()

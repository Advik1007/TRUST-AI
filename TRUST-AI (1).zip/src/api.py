"""FastAPI surface for Trust AI — predict + student + action + chat agents."""

from __future__ import annotations

import os

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from src.action_parser import parse_actions
from src.assistant import chat
from src.brand import AI_NAME, PRODUCT_NAME, TAGLINE
from src.inference import predict
from src.student_assistant import student_reply

load_dotenv()

app = FastAPI(
    title=PRODUCT_NAME,
    version="1.0.0",
    description=f"{TAGLINE} Powered by {AI_NAME}; Gemini assists Google tools only.",
)


class PredictRequest(BaseModel):
    features: list[float] | None = Field(
        default=None,
        description="Optional feature vector (length 16). Zeros if omitted.",
    )


class ChatRequest(BaseModel):
    message: str = Field(..., min_length=1)
    mode: str | None = Field(
        default=None,
        description="Optional: chat | student | action",
    )


class StudentRequest(BaseModel):
    question: str = Field(..., min_length=1)


class ActionRequest(BaseModel):
    request: str = Field(..., min_length=1)


@app.get("/health")
def health() -> dict:
    return {
        "ok": True,
        "assistant": AI_NAME,
        "product": PRODUCT_NAME,
        "agents": [
            "chat",
            "student",
            "action_parser",
            "predict",
            "email",
        ],
    }


@app.get("/agents")
def agents() -> dict:
    return {
        "product": PRODUCT_NAME,
        "engine": AI_NAME,
        "agents": {
            "chat": {
                "endpoint": "POST /chat",
                "cli": "python -m src.assistant",
                "role": "Core Trust AI ecosystem assistant",
            },
            "student": {
                "endpoint": "POST /student",
                "cli": "python -m src.student_assistant",
                "role": "Student Mode — step-by-step learning",
            },
            "action_parser": {
                "endpoint": "POST /actions",
                "cli": "python -m src.action_parser",
                "role": "Calendar / Tasks / Gmail JSON intents",
            },
            "predict": {
                "endpoint": "POST /predict",
                "cli": "python -m src.inference",
                "role": "On-device PyTorch Trust 1.0 stub",
            },
            "email": {
                "endpoint": "CLI python -m src.email_assistant",
                "cli": "python -m src.email_tool | python -m src.email_assistant",
                "role": "Gmail-style send_email (Gemini tool calling)",
            },
        },
    }


@app.post("/predict")
def predict_route(body: PredictRequest) -> dict:
    try:
        return predict(body.features)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.post("/chat")
def chat_route(body: ChatRequest) -> dict:
    return chat(body.message, mode=body.mode)


@app.post("/student")
def student_route(body: StudentRequest) -> dict:
    return {
        "assistant": PRODUCT_NAME,
        "engine": AI_NAME,
        "mode": "student",
        "reply": student_reply(body.question),
    }


@app.post("/actions")
def actions_route(body: ActionRequest) -> dict:
    return {
        "assistant": PRODUCT_NAME,
        "engine": AI_NAME,
        "mode": "action",
        "action": parse_actions(body.request),
    }


def main() -> None:
    import uvicorn

    host = os.getenv("TRUST_AI_HOST", "127.0.0.1")
    port = int(os.getenv("TRUST_AI_PORT", "8765"))
    uvicorn.run("src.api:app", host=host, port=port, reload=True)


if __name__ == "__main__":
    main()

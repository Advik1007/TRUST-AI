"""Load Trust 1.0 checkpoint and run a local prediction."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import torch

from src.device import get_device
from src.model import TrustAIModel

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
CHECKPOINT = DATA_DIR / "trust_ai_checkpoint.pt"


def load_model(checkpoint: Path | None = None) -> tuple[TrustAIModel, torch.device]:
    device = get_device()
    path = checkpoint or CHECKPOINT
    model = TrustAIModel()
    if path.is_file():
        blob = torch.load(path, map_location=device, weights_only=False)
        model.load_state_dict(blob["state_dict"])
    model.to(device)
    model.eval()
    return model, device


@torch.inference_mode()
def predict(features: list[float] | None = None) -> dict[str, Any]:
    model, device = load_model()
    if features is None:
        feats = torch.zeros(1, model.input_dim, device=device)
    else:
        if len(features) != model.input_dim:
            raise ValueError(f"expected {model.input_dim} features, got {len(features)}")
        feats = torch.tensor([features], dtype=torch.float32, device=device)

    logits = model(feats)
    probs = torch.softmax(logits, dim=-1)[0]
    pred = int(torch.argmax(probs).item())
    return {
        "assistant": "Trust 1.0",
        "device": str(device),
        "prediction": pred,
        "probabilities": [float(p) for p in probs.tolist()],
    }


def main() -> None:
    print(predict())


if __name__ == "__main__":
    main()

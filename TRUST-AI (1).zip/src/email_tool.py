"""SMTP send_email — Google/Gmail path used by Trust 1.0 (dry-run without secrets)."""

from __future__ import annotations

import os
import smtplib
from email.message import EmailMessage
from typing import Any

from dotenv import load_dotenv

load_dotenv()


def _clean(value: str | None) -> str:
    return (value or "").strip()


def smtp_configured() -> bool:
    return bool(_clean(os.getenv("SMTP_USER")) and _clean(os.getenv("SMTP_PASS")))


def send_email(recipient: str, subject: str, body: str) -> dict[str, Any]:
    """Send mail via SMTP. Dry-runs when credentials missing or SMTP_DRY_RUN=1."""
    to = recipient.strip()
    subj = subject.strip()
    text = body.strip()
    if not to or not subj or not text:
        return {"ok": False, "error": "recipient, subject, and body are required"}

    dry = os.getenv("SMTP_DRY_RUN", "").strip() in {"1", "true", "yes"} or not smtp_configured()
    from_addr = _clean(os.getenv("SMTP_FROM")) or _clean(os.getenv("SMTP_USER")) or "trust@localhost"
    host = _clean(os.getenv("SMTP_HOST")) or "smtp.gmail.com"
    port = int(_clean(os.getenv("SMTP_PORT")) or "587")
    user = _clean(os.getenv("SMTP_USER"))
    password = _clean(os.getenv("SMTP_PASS")).replace(" ", "")

    msg = EmailMessage()
    msg["Subject"] = subj
    msg["From"] = from_addr
    msg["To"] = to
    msg.set_content(text)

    if dry:
        return {
            "ok": True,
            "dry_run": True,
            "to": to,
            "subject": subj,
            "via": "Trust 1.0 email tool (dry-run)",
        }

    with smtplib.SMTP(host, port, timeout=30) as smtp:
        smtp.ehlo()
        smtp.starttls()
        smtp.login(user, password)
        smtp.send_message(msg)

    return {
        "ok": True,
        "dry_run": False,
        "to": to,
        "subject": subj,
        "via": "Trust 1.0 email tool",
    }


def main() -> None:
    import argparse

    parser = argparse.ArgumentParser(description="Trust 1.0 send_email")
    parser.add_argument("--to", required=True)
    parser.add_argument("--subject", required=True)
    parser.add_argument("--body", required=True)
    args = parser.parse_args()
    print(send_email(args.to, args.subject, args.body))


if __name__ == "__main__":
    main()

"""Train the Trust 1.0 stub and save a local checkpoint."""

from __future__ import annotations

from pathlib import Path

import torch
from torch import nn

from src.device import get_device
from src.model import TrustAIModel

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
CHECKPOINT = DATA_DIR / "trust_ai_checkpoint.pt"


def main() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    device = get_device()
    model = TrustAIModel().to(device)
    opt = torch.optim.Adam(model.parameters(), lr=1e-3)
    loss_fn = nn.CrossEntropyLoss()

    # Synthetic toy batch — proves the local train loop.
    x = torch.randn(64, model.input_dim, device=device)
    y = torch.randint(0, model.num_classes, (64,), device=device)

    model.train()
    for step in range(50):
        opt.zero_grad(set_to_none=True)
        logits = model(x)
        loss = loss_fn(logits, y)
        loss.backward()
        opt.step()
        if step % 10 == 0:
            print(f"step={step} loss={loss.item():.4f} device={device}")

    torch.save(
        {
            "state_dict": model.state_dict(),
            "input_dim": model.input_dim,
            "num_classes": model.num_classes,
            "device_trained": str(device),
        },
        CHECKPOINT,
    )
    print(f"saved {CHECKPOINT}")


if __name__ == "__main__":
    main()

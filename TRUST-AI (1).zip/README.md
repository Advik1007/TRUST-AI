# Trust AI · Trust 1.0

Personal AI ecosystem — **Trust AI** (powered by **Trust 1.0**, assisted by Gemini for Google tools only).

GitHub: https://github.com/Advik1007/TRUST-AI

## Agents (all included)

| Agent | Role | CLI | API |
|-------|------|-----|-----|
| **Chat** | Core Trust AI ecosystem assistant | `python -m src.assistant` | `POST /chat` |
| **Student** | Step-by-step study coach | `python -m src.student_assistant` | `POST /student` |
| **Action Parser** | Calendar / Tasks / Gmail → JSON | `python -m src.action_parser` | `POST /actions` |
| **Predict** | On-device PyTorch stub | `python -m src.inference` | `POST /predict` |
| **Email** | Gmail-style `send_email` | `python -m src.email_assistant` | (CLI + tool) |

Prompts live in `src/prompts.py` (core + student + action parser).

## Setup

```bash
cd TRUST-AI   # or trust-ai
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env   # add GEMINI_API_KEY / SMTP_* yourself — never commit
```

## Run API

```bash
python -m src.api
# http://127.0.0.1:8765/health
# http://127.0.0.1:8765/agents
```

```bash
curl -s http://127.0.0.1:8765/agents | jq

curl -s -X POST http://127.0.0.1:8765/student \
  -H 'Content-Type: application/json' \
  -d '{"question":"Explain photosynthesis for class 8"}'

curl -s -X POST http://127.0.0.1:8765/actions \
  -H 'Content-Type: application/json' \
  -d '{"request":"Email alex@example.com about Friday study group"}'

curl -s -X POST http://127.0.0.1:8765/chat \
  -H 'Content-Type: application/json' \
  -d '{"message":"Who are you?"}'
```

## Local model

```bash
python -m src.train
python -m src.inference
```

## Secrets

| Name | Needed for |
|------|------------|
| `GEMINI_API_KEY` | Chat / Student / Action Parser / email agent |
| `SMTP_*` | Live email (else dry-run) |

Never paste secrets into chat. Use `.env` or your host secret store.
